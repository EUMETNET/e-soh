
import tempfile
import requests
import shutil
import json


OSCAR_DL_URL = "https://oscar.wmo.int/surface/rest/api/search/station"
#OSCAR_DL_URL = "https://oscar.wmo.int/surface/rest/api/search/station?territoryName=NOR"


with tempfile.SpooledTemporaryFile(max_size=100000000, mode="w+b") as tmpfile:
    with requests.get(OSCAR_DL_URL, stream=True) as r:
        r.raise_for_status()
        shutil.copyfileobj(r.raw, tmpfile)
        # Process the file as needed
        print(f"Downloaded file size: {tmpfile.tell()} bytes")
        tmpfile.seek(0)
        json_object = json.load(tmpfile)
        with open("oscar_stations.json", "w") as out_json:
            json.dump(json_object, out_json, indent=4, ensure_ascii=False)



