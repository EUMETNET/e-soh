/*
 * (C) Copyright 2023, met.no
 *
 * This file is part of the Norbufr BUFR en/decoder
 *
 * Author: istvans@met.no
 *
 */

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <sstream>

#include "rapidjson/document.h"
#include "rapidjson/prettywriter.h"

#include "Descriptor.h"
#include "NorBufr.h"
#include "Tables.h"

#include "covjson2bufr.h"

// meas[rodeo:wigosId][time][parameter] = value
std::map<std::string, std::map<std::string, std::map<std::string, double>>>
    meas;

// unit_str[rodeo:wigosId][parameter] = unit
std::map<std::string, std::map<std::string, std::string>> unit;

// geo_loc[rodeo:wigosId][axis_x] = latitude
// geo_loc[rodeo:wigosId][axis_y] = longitude
std::map<std::string, std::map<std::string, double>> geo_loc;

struct ret_bufr covjson2bufr(std::string covjson_str, std::string bufr_template,
                             NorBufr *bufr, bool time_now) {
  struct ret_bufr ret;
  meas.clear();
  geo_loc.clear();
  unit.clear();

  if (bufr_template == "default")
    return covjson2bufr_default(covjson_str, bufr, time_now);
  std::cerr << "Unknown BUFR template name: " << bufr_template << "\n";
  return ret;
}

bool encoding_coverage(rapidjson::Value::ConstValueIterator it,
                       std::string wigosId) {

  for (rapidjson::Value::ConstMemberIterator cov_it = it->MemberBegin();
       cov_it != it->MemberEnd(); ++cov_it) {

    if (!strcmp(cov_it->name.GetString(), "type")) {
      if (strcmp(cov_it->value.GetString(), "Coverage")) {
        std::cerr << "WARNING: Unknown coverage type: "
                  << cov_it->value.GetString() << "[Coverage]\n";
        continue;
      } else {
        // COVERAGE type OK
        continue;
      }
    }

    double axis_x;
    double axis_y;
    double axis_z;
    std::vector<std::string> axis_t;

    if (!strcmp(cov_it->name.GetString(), "domain")) {
      if (cov_it->value.HasMember("type") &&
          cov_it->value["type"] == "Domain") {

        if (cov_it->value.HasMember("domainType") &&
            cov_it->value["domainType"] == "PointSeries") {

          axis_x = cov_it->value["axes"]["x"]["values"][0].GetDouble();
          axis_y = cov_it->value["axes"]["y"]["values"][0].GetDouble();
          if (cov_it->value["axes"].HasMember("z")) {
            axis_z = cov_it->value["axes"]["z"]["values"][0].GetDouble();
          } else
            axis_z = 0.0;
          geo_loc[wigosId]["lat"] = axis_x;
          geo_loc[wigosId]["lon"] = axis_y;
          geo_loc[wigosId]["hei"] = axis_z;

          // Units
          std::map<std::string, std::string> unit_str;
          if (it->HasMember("parameters")) {
            for (rapidjson::Value::ConstMemberIterator par_it =
                     ((*it)["parameters"]).MemberBegin();
                 par_it != ((*it)["parameters"]).MemberEnd(); ++par_it) {

              std::string param_name = par_it->name.GetString();
              std::string unit_str =
                  par_it->value["unit"]["label"]["en"].GetString();
              unit[wigosId][param_name] = unit_str;
            }
          }

          int t_index = 0;
          for (rapidjson::Value::ConstValueIterator tit =
                   cov_it->value["axes"]["t"]["values"].Begin();
               tit != cov_it->value["axes"]["t"]["values"].End(); ++tit) {

            axis_t.push_back(tit->GetString());
            if (it->HasMember("ranges")) {

              for (rapidjson::Value::ConstMemberIterator rng_it =
                       ((*it)["ranges"]).MemberBegin();
                   rng_it != ((*it)["ranges"]).MemberEnd(); ++rng_it) {
                double dvalue = rng_it->value["values"][t_index].GetDouble();

                std::string standard_name = rng_it->name.GetString();
                meas[wigosId][tit->GetString()][standard_name] = dvalue;
              }
            }

            ++t_index;
          }
        }
      }
    }
  }

  return true;
}

struct ret_bufr covjson2bufr_default(std::string covjson_str, NorBufr *bufr,
                                     bool time_now) {

  bool delete_bufr = false;
  if (bufr == nullptr) {
    bufr = new NorBufr;
    delete_bufr = true;
  }

  struct ret_bufr ret = {nullptr, 0};

  rapidjson::Document covjson;

  if (covjson.Parse(covjson_str.c_str()).HasParseError()) {
    std::cerr << "E-SOH covjson message parsing Error!!!\n";
    return ret;
  }

  std::string wigosId;

  if (covjson.HasMember("coverages") && covjson["coverages"].IsArray()) {
    for (rapidjson::Value::ConstValueIterator it = covjson["coverages"].Begin();
         it != covjson["coverages"].End(); ++it) {

      if (it->HasMember("metocean:wigosId")) {
        wigosId = (*it)["metocean:wigosId"].GetString();
      }
      encoding_coverage(it, wigosId);
    }
  } else {
    if (covjson.HasMember("type") && covjson["type"] == "Coverage") {
      if (covjson.HasMember("metocean:wigosId")) {
        wigosId = covjson["metocean:wigosId"].GetString();

        rapidjson::Value rjarray(rapidjson::kArrayType);
        rapidjson::Document::AllocatorType &allocator = covjson.GetAllocator();
        rjarray.PushBack(covjson, allocator);
        rapidjson::Value::ConstValueIterator it = rjarray.Begin();
        encoding_coverage(it, wigosId);
      }
    }
  }

  std::set<std::string> params_prec;
  std::set<std::string> params_temp;
  std::set<std::string> params_rad;
  std::set<std::string> params_rad_minmax;

  bool include_wind = false;
  bool include_pressure = false;
  bool include_temp_hum_synop = false;
  bool include_visibility = false;

  int subsets = 0;
  // Count subsets
  for (auto w = meas.begin(); w != meas.end(); ++w) {
    for (auto t = w->second.begin(); t != w->second.end(); ++t) {
      ++subsets;

      auto params_prec_m =
          find_parameter_names(*t, "precipitation_amount", "", "sum", "");
      params_prec.merge(params_prec_m);

      auto params_max_m =
          find_parameter_names(*t, "air_temperature", "", "maximum", "");
      params_temp.merge(params_max_m);

      auto params_min_m =
          find_parameter_names(*t, "air_temperature", "", "minimum", "");
      params_temp.merge(params_min_m);

      auto params_ldrad_sum = find_parameter_names(
          *t, "integral_wrt_time_of_surface_downwelling_longwave_flux_in_air",
          "", "sum", "");
      params_rad.merge(params_ldrad_sum);
      auto params_ldrad_min = find_parameter_names(
          *t, "integral_wrt_time_of_surface_downwelling_longwave_flux_in_air",
          "", "minimum", "");
      params_rad_minmax.merge(params_ldrad_min);
      auto params_ldrad_max = find_parameter_names(
          *t, "integral_wrt_time_of_surface_downwelling_longwave_flux_in_air",
          "", "maximum", "");
      params_rad_minmax.merge(params_ldrad_max);
      auto params_sdrad_sum = find_parameter_names(
          *t, "integral_wrt_time_of_surface_downwelling_shortwave_flux_in_air",
          "", "sum", "");
      params_rad.merge(params_sdrad_sum);
      auto params_sdrad_min = find_parameter_names(
          *t, "integral_wrt_time_of_surface_downwelling_shortwave_flux_in_air",
          "", "minimum", "");
      params_rad_minmax.merge(params_sdrad_min);
      auto params_sdrad_max = find_parameter_names(
          *t, "integral_wrt_time_of_surface_downwelling_shortwave_flux_in_air",
          "", "maximum", "");
      params_rad_minmax.merge(params_sdrad_max);

      auto params_nlrad_sum = find_parameter_names(
          *t, "integral_wrt_time_of_surface_net_downward_longwave_flux", "",
          "sum", "");
      params_rad.merge(params_nlrad_sum);
      auto params_nsrad_sum = find_parameter_names(
          *t, "integral_wrt_time_of_surface_net_downward_shortwave_flux", "",
          "sum", "");
      params_rad.merge(params_nsrad_sum);

      // Check wind values
      if (!include_wind) {
        auto params_wind_s =
            find_parameter_names(*t, "wind_speed", "", "point", "");
        auto params_wind_gust_s =
            find_parameter_names(*t, "wind_speed_of_gust", "", "point", "");
        if (params_wind_s.size() || params_wind_gust_s.size()) {
          include_wind = true;
        }
      }
      // Check pressure values
      if (!include_pressure) {
        auto params_press =
            find_parameter_names(*t, "air_pressure", "", "point", "PT0S");
        auto params_press_msl = find_parameter_names(
            *t, "air_pressure_at_mean_sea_level", "", "point", "PT0S");
        if (params_press.size() || params_press_msl.size()) {
          include_pressure = true;
        }
      }

      // Check temperature, humidity synop values for [ 3 02 032 ]
      if (!include_temp_hum_synop) {

        auto params_temp =
            find_parameter_names(*t, "air_temperature", "", "point", "");
        auto params_dew = find_parameter_names(*t, "dew_point_temperature", "",
                                               "point", "PT0S");
        auto params_hum =
            find_parameter_names(*t, "relative_humidity", "", "point", "PT0S");

        if (params_temp.size() || params_dew.size() || params_hum.size()) {
          include_temp_hum_synop = true;
        }
      }
    }
  }

  std::vector<std::string> params_pa;
  if (params_prec.size()) {
    params_pa.assign(params_prec.begin(), params_prec.end());
  }

  std::vector<std::string> params(params_temp.begin(), params_temp.end());

  std::vector<std::string> params_rd(params_rad.begin(), params_rad.end());
  std::vector<std::string> params_rd_mm(params_rad_minmax.begin(),
                                        params_rad_minmax.end());

  int test_max_subset = 30000;
  bufr->setSubset(subsets);
  subsets = 0;
  for (auto w = meas.begin(); w != meas.end(); ++w) {
    for (auto t = w->second.begin(); t != w->second.end(); ++t) {
      std::stringstream ss;
      ss << w->first;
      if (!subsets) {
        bufr->addDescriptor("301150");
      }
      for (int we = 0; we < 4; ++we) {
        std::string wi;
        getline(ss, wi, '-');
        bufr->addValue(wi);
      }

      if (!subsets) {
        bufr->addDescriptor("301090");
      }
      bufr->addValue("MISSING");              // WMO Block, TODO: OSCAR
      bufr->addValue("MISSING");              // WMO Station, TODO: OSCAR
      bufr->addValue("MISSING");              // Station or Site name
      bufr->addValue("MISSING");              // Type of Station
      bufr->addValue(t->first.substr(0, 4));  // Year
      bufr->addValue(t->first.substr(5, 2));  // Month
      bufr->addValue(t->first.substr(8, 2));  // Day
      bufr->addValue(t->first.substr(11, 2)); // Hour
      bufr->addValue(t->first.substr(14, 2)); // Minute

      bufr->addValue(geo_loc[w->first]["lat"]); // Latitude
      bufr->addValue(geo_loc[w->first]["lon"]); // Longitude
      bufr->addValue(geo_loc[w->first]["hei"]); // Height of station

      bufr->addValue("MISSING"); // Height of barometer

      // Pressure
      if (include_pressure) {
        if (!subsets) {
          bufr->addDescriptor("302031");
        }

        std::string press_value = "MISSING";
        auto press =
            find_standard_value(*t, "air_pressure", "", "point", "PT0S");
        if (press.size()) {
          if (unit[w->first]["air_pressure:0.0:point:PT0S"] == "hPa") {
            press[0].value *= 100;
          }
          press_value = std::to_string(press[0].value);
        }
        bufr->addValue(press_value);

        std::string press_msl_value = "MISSING";
        auto press_msl = find_standard_value(
            *t, "air_pressure_at_mean_sea_level", "", "point", "PT0S");
        if (press_msl.size()) {
          if (unit[w->first]["air_pressure:0.0:point:PT0S"] == "hPa") {
            press_msl[0].value *= 100;
          }
          press_msl_value = std::to_string(press_msl[0].value);
        }
        bufr->addValue(press_msl_value);

        bufr->addValue("MISSING"); // 3-HOUR PRESSURE CHANGE
        bufr->addValue("MISSING"); // CHARACTERISTIC OF PRESSURE TENDENCY
        bufr->addValue("MISSING"); // 24-HOUR PRESSURE CHANGE
        bufr->addValue("MISSING"); // PRESSURE
        bufr->addValue("MISSING"); // GEOPOTENTIAL HEIGHT
      }

      // Temperature
      if (include_temp_hum_synop) {
        if (!subsets) {
          bufr->addDescriptor("302032");
        }

        std::string temp_value = "MISSING";
        std::string temp_sensor_level = "MISSING";

        auto temp =
            find_standard_value(*t, "air_temperature", "", "point", "PT0S");
        if (!temp.size()) {
          for (int j = 10; j > 1; --j) {
            std::string period_str = "PT" + std::to_string(j) + "M";
            temp = find_standard_value(*t, "air_temperature", "", "point",
                                       period_str);
            if (temp.size()) {
              break;
            }
          }
        }
        if (temp.size()) {
          temp_sensor_level = temp[0].level;
          double kelvin_value = unit[w->first]["air_temperature"] == "K"
                                    ? temp[0].value
                                    : temp[0].value + 273.16;
          temp_value = std::to_string(kelvin_value);
        }

        bufr->addValue(temp_sensor_level);
        bufr->addValue(temp_value);

        std::string dew_value = "MISSING";
        auto dew = find_standard_value(*t, "dew_point_temperature", "", "point",
                                       "PT0S");
        if (dew.size()) {
          double kelvin_value = unit[w->first]["dew_point_temperature"] == "K"
                                    ? dew[0].value
                                    : dew[0].value + 273.16;
          dew_value = std::to_string(kelvin_value);
        }
        bufr->addValue(dew_value);

        std::string hum_value = "MISSING";
        auto hum =
            find_standard_value(*t, "relative_humidity", "", "point", "PT0S");
        if (hum.size()) {
          hum_value = std::to_string(hum[0].value);
        }
        bufr->addValue(hum_value);
      }
      if (include_visibility) {
        // visibility
        if (!subsets) {
          bufr->addDescriptor("302033");
        }

        bufr->addValue("MISSING"); // visibility sensor height
        bufr->addValue("MISSING"); // Horizontal visibility
      }

      // Extreme temperature data: [0 07 032] [0 04 024] [0 12 111] [0 04 024]
      // [0 12 112] Instead of 3 02 041, because time unit is hour

      if (params.size()) {
        if (!subsets) {
          bufr->addDescriptor("105000");
          bufr->addDescriptor("031001");
        }

        int more_min_temp_levels = 0;
        std::map<std::string, std::vector<std::string>> extra_levels;
        // Check all available levels
        for (size_t i = 0; i < params.size(); ++i) {
          auto temp_max = find_standard_value(*t, "air_temperature", "",
                                              "maximum", params[i]);
          auto temp_min = find_standard_value(*t, "air_temperature", "",
                                              "minimum", params[i]);

          // Add more levels to minimum temperature
          for (auto mt : temp_min) {
            if (mt.level != temp_max[0].level) {
              ++more_min_temp_levels;
            }
          }
        }

        bufr->addValue(params.size());

        for (size_t i = 0; i < params.size(); ++i) {
          int period = periodstr_to_int(params[i]) / 60;

          std::string temp_max_value = "MISSING";
          std::string temp_min_value = "MISSING";
          std::string temp_sensor_level = "MISSING";

          auto temp_max = find_standard_value(*t, "air_temperature", "",
                                              "maximum", params[i]);
          if (temp_max.size()) {
            temp_sensor_level = temp_max[0].level;
            double kelvin_value = unit[w->first]["air_temperature"] == "K"
                                      ? temp_max[0].value
                                      : temp_max[0].value + 273.16;
            temp_max_value = std::to_string(kelvin_value);
          }

          auto temp_min = find_standard_value(*t, "air_temperature", "",
                                              "minimum", params[i]);

          int temp_min_index = 0;
          if (temp_min.size()) {
            if (temp_min.size() > 1) {
              for (int ii = 0; i < temp_min.size(); ++ii) {
                if (temp_max.size() &&
                    temp_max[0].level == temp_min[ii].level) {
                  temp_min_index = ii;
                  break;
                }
              }
            }
            if (temp_sensor_level == "MISSING") {
              temp_sensor_level = temp_min[temp_min_index].level;
            }
            double kelvin_value = unit[w->first]["air_temperature"] == "K"
                                      ? temp_min[temp_min_index].value
                                      : temp_min[temp_min_index].value + 273.16;
            temp_min_value = std::to_string(kelvin_value);
          }

          if (!subsets && !i) {
            bufr->addDescriptor("007032");
          }
          bufr->addValue(temp_sensor_level); // 0 07 032 Height of sensor above
                                             // local ground
          if (!subsets && !i) {
            bufr->addDescriptor("004025");
          }

          bufr->addValue(period); // 0 04 024 Time period or displacement
          if (!subsets && !i) {
            bufr->addDescriptor("012111");
          }
          bufr->addValue(temp_max_value); // 0 12 111 Maximum temperature, at
                                          // height and over period specified

          if (!subsets && !i) {
            bufr->addDescriptor("004025");
          }
          bufr->addValue(period); // 0 04 024 Time period or displacement
          if (!subsets && !i) {
            bufr->addDescriptor("012112");
          }
          bufr->addValue(temp_min_value); // 0 12 112 Minimum temperature, at
                                          // height and over period specified
        }
      }
      if (include_wind) {
        // WIND
        if (!subsets) {
          bufr->addDescriptor("302042");
        }

        std::string wind_speed_value = "MISSING";
        std::string wind_dir_value = "MISSING";
        std::string wind_period_value = "MISSING";
        std::string wind_sensor_level = "MISSING";

        auto params_wind_s =
            find_parameter_names(*t, "wind_speed", "", "point", "");

        std::vector<std::string> params_wind(params_wind_s.begin(),
                                             params_wind_s.end());

        if (params_wind.size()) {
          auto wind_speed = find_standard_value(*t, "wind_speed", "", "point",
                                                params_wind[0]);
          auto wind_dir = find_standard_value(*t, "wind_from_direction", "",
                                              "point", params_wind[0]);

          if (wind_speed.size()) {
            wind_sensor_level = wind_speed[0].level;
            wind_speed_value = std::to_string(wind_speed[0].value);
          }
          if (wind_dir.size()) {
            wind_dir_value = std::to_string(wind_dir[0].value);
          }
          int period = periodstr_to_int(params_wind[0]) / 60;
          wind_period_value = std::to_string(period);
        }

        std::vector<std::string> wind_gust_speed_value = {"MISSING", "MISSING"};
        std::vector<std::string> wind_gust_dir_value = {"MISSING", "MISSING"};
        std::vector<std::string> wind_gust_period = {"MISSING", "MISSING"};

        auto params_wind_gust_s =
            find_parameter_names(*t, "wind_speed_of_gust", "", "point", "");

        std::vector<std::string> params_wind_gust(params_wind_gust_s.begin(),
                                                  params_wind_gust_s.end());
        if (params_wind_gust.size()) {

          int wind_guest_count =
              params_wind.size() < 2 ? static_cast<int>(params_wind.size()) : 2;

          for (int i = 0; i < wind_guest_count; ++i) {

            auto wind_gust_speed = find_standard_value(
                *t, "wind_speed_of_gust", "", "point", params_wind_gust[i]);

            if (wind_gust_speed.size()) {
              wind_gust_speed_value[i] =
                  std::to_string(wind_gust_speed[0].value);
            }

            auto wind_gust_dir =
                find_standard_value(*t, "wind_gust_from_direction", "", "point",
                                    params_wind_gust[i]);

            if (wind_gust_dir.size()) {
              wind_gust_dir_value[i] = std::to_string(wind_gust_dir[0].value);
            }

            int period = periodstr_to_int(params_wind_gust[i]) / 60;
            wind_gust_period[i] = std::to_string(period);
          }
        }

        bufr->addValue(
            wind_sensor_level); // HEIGHT OF SENSOR ABOVE LOCAL GROUND
        bufr->addValue(
            "MISSING"); // TYPE OF INSTRUMENTATION FOR WIND MEASUREMENT
        bufr->addValue("MISSING");         // TIME SIGNIFICANCE
        bufr->addValue(wind_period_value); // TIME PERIOD OR DISPLACEMENT
        bufr->addValue(wind_dir_value);    // WIND DIRECTION
        bufr->addValue(wind_speed_value);  // WIND SPEED
        bufr->addValue("MISSING");         // TIME SIGNIFICANCE

        // repeat
        bufr->addValue(wind_gust_period[0]);      // TIME PERIOD OR DISPLACEMEN
        bufr->addValue(wind_gust_dir_value[0]);   // MAXIMUM WIND GUST DIRECTION
        bufr->addValue(wind_gust_speed_value[0]); // MAXIMUM WIND GUST SPEED

        bufr->addValue(wind_gust_period[1]);      // TIME PERIOD OR DISPLACEMEN
        bufr->addValue(wind_gust_dir_value[1]);   // MAXIMUM WIND GUST DIRECTION
        bufr->addValue(wind_gust_speed_value[1]); // MAXIMUM WIND GUST SPEED
      }

      std::string rad_sensor_level = "MISSING";
      // Radiation
      if (params_rd.size()) {
        if (!subsets) {
          bufr->addDescriptor("106000");
          bufr->addDescriptor("031001");
        }
        bufr->addValue(params_rd.size());

        for (size_t i = 0; i < params_rd.size(); ++i) {
          std::string ldrad_value = "MISSING";
          std::string sdrad_value = "MISSING";
          std::string nlrad_value = "MISSING";
          std::string nsrad_value = "MISSING";

          auto ldrad_sum = find_standard_value(
              *t,
              "integral_wrt_time_of_surface_downwelling_longwave_flux_in_air",
              "", "sum", params_rd[i]);

          if (ldrad_sum.size()) {
            rad_sensor_level = ldrad_sum[0].level;
            ldrad_value = std::to_string(ldrad_sum[0].value);
          }

          int period = periodstr_to_int(params_rd[i]) / 60;

          auto sdrad_sum = find_standard_value(
              *t,
              "integral_wrt_time_of_surface_downwelling_shortwave_flux_in_air",
              "", "sum", params_rd[i]);

          if (sdrad_sum.size()) {
            if (rad_sensor_level == "MISSING") {
              rad_sensor_level = sdrad_sum[0].level;
            }
            sdrad_value = std::to_string(sdrad_sum[0].value);
          }

          auto nlrad_sum = find_standard_value(
              *t, "integral_wrt_time_of_surface_net_downward_longwave_flux", "",
              "sum", params_rd[i]);

          if (nlrad_sum.size()) {
            if (rad_sensor_level == "MISSING") {
              rad_sensor_level = nlrad_sum[0].level;
            }
            nlrad_value = std::to_string(nlrad_sum[0].value);
          }

          auto nsrad_sum = find_standard_value(
              *t, "integral_wrt_time_of_surface_net_downward_shortwave_flux",
              "", "sum", params_rd[i]);

          if (nsrad_sum.size()) {
            if (rad_sensor_level == "MISSING") {
              rad_sensor_level = nsrad_sum[0].level;
            }
            nsrad_value = std::to_string(nsrad_sum[0].value);
          }

          if (!subsets && !i) {
            bufr->addDescriptor("007032");
          }
          bufr->addValue(
              rad_sensor_level); // 0 07 032 Height of sensor above local ground
          if (!subsets && !i) {
            bufr->addDescriptor("004025");
          }
          bufr->addValue(period); // 0 04 024 Time period or displacement
          if (!subsets && !i) {
            bufr->addDescriptor("014002"); // Long-wave radiation, integrated
                                           // over period specified
          }
          bufr->addValue(ldrad_value);
          if (!subsets && !i) {
            bufr->addDescriptor("014004"); // Short-wave radiation, integrated
                                           // over period specified
          }
          bufr->addValue(sdrad_value);
          if (!subsets && !i) {
            bufr->addDescriptor("014012"); // Net long-wave radiation,
                                           // integrated over period specified
          }
          bufr->addValue(nlrad_value);
          if (!subsets && !i) {
            bufr->addDescriptor("014014"); // Net short-wave radiation,
                                           // integrated over period specified
          }
          bufr->addValue(nsrad_value);
        }
      }

      // Radiation 2
      if (params_rd_mm.size()) {
        if (!subsets) {
          bufr->addDescriptor("106000");
          bufr->addDescriptor("031001");
        }
        bufr->addValue(params_rd_mm.size());

        for (size_t i = 0; i < params_rd_mm.size(); ++i) {

          std::string ldrad_min_value = "MISSING";
          std::string ldrad_max_value = "MISSING";
          std::string sdrad_min_value = "MISSING";
          std::string sdrad_max_value = "MISSING";
          std::string rad_sensor_level = "MISSING";

          int period = periodstr_to_int(params_rd_mm[i]) / 60;

          auto ldrad_min = find_standard_value(
              *t,
              "integral_wrt_time_of_surface_downwelling_longwave_flux_in_air",
              "", "minimum", params_rd_mm[i]);

          if (ldrad_min.size()) {
            if (rad_sensor_level == "MISSING") {
              rad_sensor_level = ldrad_min[0].level;
            }
            ldrad_min_value = std::to_string(ldrad_min[0].value);
          }

          auto ldrad_max = find_standard_value(
              *t,
              "integral_wrt_time_of_surface_downwelling_longwave_flux_in_air",
              "", "maximum", params_rd_mm[i]);

          if (ldrad_max.size()) {
            if (rad_sensor_level == "MISSING") {
              rad_sensor_level = ldrad_max[0].level;
            }
            ldrad_max_value = std::to_string(ldrad_max[0].value);
          }

          auto sdrad_min = find_standard_value(
              *t, "",
              "integral_wrt_time_of_surface_downwelling_shortwave_flux_in_air",
              "minimum", params_rd_mm[i]);

          if (sdrad_min.size()) {
            sdrad_min_value = std::to_string(sdrad_min[0].value);
            if (rad_sensor_level == "MISSING") {
              rad_sensor_level = sdrad_min[0].level;
            }
          }

          auto sdrad_max = find_standard_value(
              *t, "",
              "integral_wrt_time_of_surface_downwelling_shortwave_flux_in_air",
              "maximum", params_rd_mm[i]);

          if (sdrad_max.size()) {
            sdrad_max_value = std::to_string(sdrad_max[0].value);
            if (rad_sensor_level == "MISSING") {
              rad_sensor_level = ldrad_max[0].level;
            }
          }
          if (!subsets && !i) {
            bufr->addDescriptor("007032");
          }
          bufr->addValue(
              rad_sensor_level); // 0 07 032 Height of sensor above local ground

          if (!subsets && !i) {
            bufr->addDescriptor("004025");
          }
          bufr->addValue(period); // 0 04 025 Time period or displacement

          // Downward Long-wave radiation, integrated over period specified:
          // always positive!!! see [3 07 092]
          if (!subsets && !i) {
            bufr->addDescriptor("014002");
          }
          bufr->addValue(ldrad_max_value);

          // Upward Long-wave radiation, integrated over period specified:
          // always negative!!! see [3 07 092]
          if (!subsets && !i) {
            bufr->addDescriptor("014002");
          }
          bufr->addValue(ldrad_min_value);

          // Downward Short-wave radiation, integrated over period specified:
          // always positive!!!
          if (!subsets && !i) {
            bufr->addDescriptor("014004");
          }
          bufr->addValue(sdrad_max_value);

          // Upward Short-wave radiation, integrated over period specified:
          // always negative!!!
          if (!subsets && !i) {
            bufr->addDescriptor("014004");
          }
          bufr->addValue(sdrad_min_value);
        }
      }

      if (params_pa.size()) {
        if (!subsets) {
          bufr->addDescriptor("103000");
          bufr->addDescriptor("031001");
        }
        bufr->addValue(params_pa.size());
        for (size_t i = 0; i < params_pa.size(); ++i) {

          std::string prec_amount_value = "MISSING";
          std::string prec_sensor_level = "MISSING";

          auto prec_amount = find_standard_value(*t, "precipitation_amount", "",
                                                 "sum", params_pa[i]);
          if (prec_amount.size()) {
            prec_sensor_level = prec_amount[0].level;
            prec_amount_value = std::to_string(prec_amount[0].value);
          }

          int period = periodstr_to_int(params_pa[i]) / 60;

          if (!subsets && !i) {
            bufr->addDescriptor("007032");
          }
          bufr->addValue(prec_sensor_level); // 0 07 032 Height of sensor
                                             // above local ground
          if (!subsets && !i) {
            bufr->addDescriptor("004025");
          }
          bufr->addValue(period); // 0 04 024 Time period or displacement

          if (!subsets && !i) {
            bufr->addDescriptor("013011");
          }
          bufr->addValue(
              prec_amount_value); // 0 13 011 Total precipitation/total
                                  // water equivalent
        }
      }

      // END of FIRST SUBSET, subset end indicator
      if (!subsets) {
        bufr->addDescriptor(0);
      }

      if (subsets == test_max_subset) {
        goto stream_end;
      }
      ++subsets;
    }
  }

stream_end:

  bufr->encodeBufr();

  // Set Section1 datetime
  if (time_now) {
    time_t now = time(0);
    struct tm curr_dt;
    memset(&curr_dt, 0, sizeof(curr_dt));
#if defined(_MSC_VER)
    curr_dt = *(gmtime(reinterpret_cast<const time_t *const>(&now)));
#else
    gmtime_r(&now, &curr_dt);
#endif

    bufr->setYear(curr_dt.tm_year + 1900);
    bufr->setMonth(curr_dt.tm_mon + 1);
    bufr->setDay(curr_dt.tm_mday);
    bufr->setHour(curr_dt.tm_hour);
    bufr->setMinute(curr_dt.tm_min);
    bufr->setSecond(curr_dt.tm_sec);
  }

  const uint8_t *rbe = bufr->toBuffer();

  ret.buffer = new char[bufr->length()];
  memcpy(ret.buffer, reinterpret_cast<const char *>(rbe), bufr->length());

  if (delete_bufr) {
    delete bufr;
  }
  ret.size = bufr->length();

  return ret;
}

std::map<std::string, double>::iterator
find_standard_value(std::map<std::string, double>::iterator beg,
                    std::map<std::string, double>::iterator end,
                    std::string standard_name, std::string /*level*/,
                    std::string method, std::string period) {

  std::vector<struct val_lev> ret;

  auto range = std::find_if(
      beg, end,
      [standard_name, method,
       period](const std::pair<std::string, double> &tt) -> bool {
        bool retr =
            (tt.first.substr(0, standard_name.size()) == standard_name &&
             tt.first.substr(tt.first.size() - method.size() - period.size() -
                                 2,
                             method.size() + period.size() + 2) ==
                 (":" + method + ":" + period));
        return retr;
      });

  return range;
}

std::vector<struct val_lev>
find_standard_value(std::pair<std::string, std::map<std::string, double>> t,
                    std::string standard_name, std::string level,
                    std::string method, std::string period) {
  std::vector<struct val_lev> ret;

  auto range = t.second.begin();

  while (range != t.second.end()) {
    range = find_standard_value(range, t.second.end(), standard_name, level,
                                method, period);

    if (range != t.second.end()) {
      auto level_str_beg = range->first.find(':');
      if (level_str_beg != std::string::npos) {
        auto level_str_end = range->first.find(':', level_str_beg + 1);
        if (level_str_end != std::string::npos) {
          std::string level_str = range->first.substr(
              level_str_beg + 1, level_str_end - level_str_beg - 1);
          if (!level.size() || level_str == level) {
            ret.push_back({range->second, level_str});
          }
        }
      }
      range++;
    }
  }

  return ret;
}

std::set<std::string>
find_parameter_names(std::pair<std::string, std::map<std::string, double>> t,
                     std::string standard_name, std::string /*level*/,
                     std::string method, std::string period) {

  std::set<std::string> ret;

  auto range = t.second.begin();
  do {
    range = std::find_if(
        range, t.second.end(),
        [standard_name, method,
         period](const std::pair<std::string, double> &tt) -> bool {
          size_t ci = tt.first.rfind(':');
          bool retr =
              (tt.first.substr(0, standard_name.size()) == standard_name &&
               tt.first.substr(ci - method.size() - period.size() - 1,
                               method.size() + 2) == (":" + method + ":"));
          return retr;
        });
    if (range != t.second.end()) {
      std::string param_name = range->first.substr(range->first.rfind(':') + 1);
      ret.insert(param_name);
      range++;
    }
  } while (range != t.second.end());

  return ret;
}

int periodstr_to_int(std::string pstr) {
  int ret = 0;
  if (pstr.size()) {
    if (pstr.substr(0, 2) != "PT") {
      std::cout << "Unknown period: " << pstr << "\n";
    } else {
      int period = stoi(pstr.substr(2, -1));
      switch (pstr.back()) {
      case 'S':
        ret = period;
        break;
      case 'M':
        ret = period * 60;
        break;
      case 'H':
        ret = period * 60 * 60;
        break;
      case 'D':
        ret = period * 60 * 60 * 24;
        break;
      default:
        std::cout << "Unknown period unit:" << pstr << "\n";
      }
    }
  }
  return -ret;
}
