import os
import sys

sys.path.append("/home/istvans/work/E-SOH/github/test_sprint/rodeo-bufr-library/src/")

from bufr_tools.getenvvalue import getOscarDumpPath
from bufr_tools.getenvvalue import getPackageRootDir
#from bufr_tools.getenvvalue import getOscarDumpPath
#from bufr_tools.getenvvalue import getPackageRootDir


from bufr_tools.bufresohmsg_py import init_oscar_py  # noqa: E402
from bufr_tools.bufresohmsg_py import oscar_wigos_find_py  # noqa: E402


OSCAR_DUMP = getOscarDumpPath()

init_oscar_py(OSCAR_DUMP)


if __name__ == "__main__":
    if len(sys.argv) > 1:
        for i, wigosId in enumerate(sys.argv):
            if i < 1:
                continue
            print(f"Search {wigosId}")
            msg = oscar_wigos_find_py(wigosId)
            print(msg)
    else:
        print("Usage: python3 oscar.py WigosId(s)")

    exit(0)
